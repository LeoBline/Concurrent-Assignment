package Allsnake;

public class Test {

}
